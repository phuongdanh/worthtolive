<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<style type="text/css" media="screen">
		body{
			background: url('public/site/images/loi-404-1.png');
			background-repeat: no-repeat;
		}
		.container{
                    border-top: 30px solid #ecaa09;
		    font-size: 20px;
                    text-align: center;
		}
		a{
			text-decoration: none;
			color: red;
		}
                h6{
                    font-size: 20px;
                    font-weight: normal;
                    
                }
                h1{
                    text-transform: uppercase;
                    font-size: 35px;
                }
                h1 span{
                    font-size: 150px;
                    color: #d64c00;
                    font-family: fantasy;
                }
	</style>
</head>
<body>
	<div class="container">
            <h6>Don't worry you will be back on track in no time!</h6>
            <h1><span>404</span> error</h1>
            <p>Page dont exist or some occured. Go to our <a href="index.php?action=home" title="">home page</a></p>
	</div>
</body>
</html>