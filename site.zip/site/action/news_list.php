<?php if(!defined('SYSPATH'))die ('Request not found!'); ?>
<?php
    echo 'This is news list!';
    
?>