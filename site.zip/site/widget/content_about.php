<?php if (!defined('SYSPATH')) die('Request not found!'); $pathforsite = 'public/site/'; ?>

<div class="content_wrapper">
    <div class="col-md-2"></div>
    <div class="col-md-8 main_content">
        <span class="name">Worth to live</span>
    </div>
    <div class="col-md-2"></div>
</div>