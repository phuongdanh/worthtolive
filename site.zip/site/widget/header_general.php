<?php if(!defined('SYSPATH'))die ('Request not found!'); $pathforsite = 'public/site/'; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>News - Worth to live</title>
        <meta charset="utf-8"></meta>
        <link rel="stylesheet" type="text/css" href="<?php echo $pathforsite; ?>css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $pathforsite; ?>css/menu.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $pathforsite; ?>css/world.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $pathforsite; ?>font-awesome/css/font-awesome.min.css">
        <script type="text/javascript" src="<?php echo $pathforsite; ?>js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo $pathforsite; ?>js/bootstrap.js"></script>
        <script type="text/javascript" src="<?php echo $pathforsite; ?>js/custome.js"></script>
        <link rel="icon" href="public/site/images/icon.png" type="image/png" sizes="16x16">
    </head>
    