<?php if (!defined('SYSPATH')) die('Request not found!'); $pathforsite = 'public/site/'; ?>

<div class="clr"></div>
<div class="content_wrapper">
    <div class="col-md-6 content_left">
        <div class="first_art">
            <span>Senate G.O.P. Digs In for Fight Over Replacing Scalia</span><br/>
            <i>20:35 16/06/2015</i>
            <img src="<?php echo $pathforsite; ?>images/enter1.jpg" style="width:100%;margin-top:10px;margin-bottom:10px;">
            <p>Antonin Scalia during his confirmation hearings in Washington in 1986. Credit Lana Harris/Associated Press
            </p>
        </div>
        <ul class="list_art">
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter2.jpg">
                <span><a href="#">Senate G.O.P. Digs In for Fight Over Replacing Scalia</a></span><br/>
                <i>20:35 16/06/2015</i>
                <p>WASHINGTON — An epic Washington political battle took shape on Sunday after the death of Justice Antonin Scalia as Senate Republicans dug in and said they would refuse to act on any Supreme Court nomination by President Obama. But the White House vowed to select a nominee within weeks.
                </p>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter3.jpg">
                <span><a href="#">Senate G.O.P. Digs In for Fight Over Replacing Scalia</a></span><br/>
                <i>20:35 16/06/2015</i>
                <p>WASHINGTON — An epic Washington political battle took shape on Sunday after the death of Justice Antonin Scalia as Senate Republicans dug in and said they would refuse to act on any Supreme Court nomination by President Obama. But the White House vowed to select a nominee within weeks.
                </p>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter4.jpg">
                <span><a href="#">Senate G.O.P. Digs In for Fight Over Replacing Scalia</a></span><br/>
                <i>20:35 16/06/2015</i>
                <p>WASHINGTON — An epic Washington political battle took shape on Sunday after the death of Justice Antonin Scalia as Senate Republicans dug in and said they would refuse to act on any Supreme Court nomination by President Obama. But the White House vowed to select a nominee within weeks.
                </p>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter5.jpg">
                <span><a href="#">Senate G.O.P. Digs In for Fight Over Replacing Scalia</a></span><br/>
                <i>20:35 16/06/2015</i>
                <p>WASHINGTON — An epic Washington political battle took shape on Sunday after the death of Justice Antonin Scalia as Senate Republicans dug in and said they would refuse to act on any Supreme Court nomination by President Obama. But the White House vowed to select a nominee within weeks.
                </p>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter6.jpg">
                <span><a href="#">Senate G.O.P. Digs In for Fight Over Replacing Scalia</a></span><br/>
                <i>20:35 16/06/2015</i>
                <p>WASHINGTON — An epic Washington political battle took shape on Sunday after the death of Justice Antonin Scalia as Senate Republicans dug in and said they would refuse to act on any Supreme Court nomination by President Obama. But the White House vowed to select a nominee within weeks.
                </p>
            </li>
            <img src="<?php echo $pathforsite; ?>images/more.png">
        </ul>
    </div>
    <div class="col-md-2 content_mid">
        <ul class="list_art">
            <span>I write</span>
            <hr>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
            </li>
            <img src="images/more.png">
        </ul>
        <ul class="list_art img">
            <span>FRom web</span>
            <hr>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter7.jpg">
                <span><a href="#">Obama move white house</a></span>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter8.jpg">
                <span><a href="#">Obama move white house</a></span>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter9.jpg">
                <span><a href="#">Obama move white house</a></span>
            </li>
            <li>
                <img src="<?php echo $pathforsite; ?>images/enter10.jpg">
                <span><a href="#">Obama move white house</a></span>
            </li>
            <img src="<?php echo $pathforsite; ?>images/more.png">
        </ul>
        <ul class="list_art gall">
            <span>Gallery</span>
            <hr>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
                <p>The accident made Russia loses of up to 1 Milion USD. Economy decline</p>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
                <p>The accident made Russia loses of up to 1 Milion USD. Economy decline</p>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
                <p>The accident made Russia loses of up to 1 Milion USD. Economy decline</p>
            </li>
            <li>
                <a href="#">Jet crash on the sky in Russia</a>
                <p>The accident made Russia loses of up to 1 Milion USD. Economy decline</p>
            </li>
            <img src="<?php echo $pathforsite; ?>images/more.png">
        </ul>
    </div>
    <div class="col-md-4 content_right">
        <ul class="desk">
            <span class="cate">From the desk</span>
            <hr class="line_title">
            <li>
                <span>Lorem ipsum dolor sit amet, consectetur</span>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                <a href="#">READ MORE</a><b>3 hours ago</b><br>
            </li>
            <li>
                <span>Lorem ipsum dolor sit amet, consectetur</span>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                <a href="#">READ MORE</a><b>3 hours ago</b><br>
            </li>
            <li>
                <span>Lorem ipsum dolor sit amet, consectetur</span>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                <a href="#">READ MORE</a><b>3 hours ago</b><br>
            </li>
            <li>
                <span>Lorem ipsum dolor sit amet, consectetur</span>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                <a href="#">READ MORE</a><b>3 hours ago</b><br>
            </li>
            <img src="<?php echo $pathforsite; ?>images/more.png">
        </ul>
        <ul class="edit">
            <span class="cate">EDITORIAL</span>
            <hr class="line_title">
            <li class="col-md-12 col-sm-6">
                <img src="<?php echo $pathforsite; ?>images/enter11.jpg" width="100%">
                <a href="#"><span class="title">Lorem ipsum dolor sit amet, consectetur</span></a>
            </li>
            <li class="col-md-12 col-sm-6">
                <img src="<?php echo $pathforsite; ?>images/enter12.jpg" width="100%">
                <a href="#"><span class="title">Lorem ipsum dolor sit amet, consectetur</span></a>
            </li>
            <li class="col-md-12 col-sm-6">
                <img src="<?php echo $pathforsite; ?>images/enter13.jpg" width="100%">
                <a href="#"><span class="title">Lorem ipsum dolor sit amet, consectetur</span></a>
            </li>
            <li class="col-md-12 col-sm-6">
                <img src="<?php echo $pathforsite; ?>images/enter14.jpg" width="100%">
                <a href="#"><span class="title">Lorem ipsum dolor sit amet, consectetur</span></a>
            </li>
            <img src="<?php echo $pathforsite; ?>images/more.png">
        </ul>
    </div>
    <div class="clr"></div>
</div>