<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <h1>Dashboard</h1>
      <ul class="breadcrumb">
                <li><a href="http://localhost/opencart/upload/admin/index.php?route=common/dashboard&amp;token=o9dInnw2E1FkkesNiP9eooxV50HVO4On">Home</a></li>
                <li><a href="http://localhost/opencart/upload/admin/index.php?route=common/dashboard&amp;token=o9dInnw2E1FkkesNiP9eooxV50HVO4On">Dashboard</a></li>
              </ul>
    </div>
  </div>