<div id="content">
    <div class="page-header">
        <div class="container-fluid">
            <div class="pull-right"><a href="admin/index.php?action=category_add" data-toggle="tooltip" title="Add New" class="btn btn-primary">
                    <i class="fa fa-plus"></i></a> 
                <a href="#" data-toggle="tooltip" title="Rebuild" class="btn btn-default">
                    <i class="fa fa-refresh"></i>
                </a>
                <button type="button" data-toggle="tooltip" title="Delete" class="btn btn-danger" onclick="confirm('Are you sure?') ? $('#form-category').submit() : false;"><i class="fa fa-trash-o"></i></button>
            </div>
            <h1>Categories</h1>
            <ul class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li><a href="#">Categories</a></li>
            </ul>
        </div>
    </div>