<?php 
    load_header();
    load_sidebar();
    load_toper('toper_user');
    load_widget('content_user');
    load_footer();
?>