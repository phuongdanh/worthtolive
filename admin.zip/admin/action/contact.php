<?php 
    load_header();
    load_sidebar();
    load_toper('toper_contact');
    load_widget('content_contact');
    load_footer();
?>