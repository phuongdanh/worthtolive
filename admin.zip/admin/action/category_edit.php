<?php 
    load_header();load_sidebar();
    load_toper('toper_category');
    load_widget('content_category_edit');
    load_footer();
?>