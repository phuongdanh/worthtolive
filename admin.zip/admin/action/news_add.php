<?php 
    load_header();
    load_sidebar();
    load_toper('toper_new');
    load_widget('content_new_add');
    load_footer();
?>