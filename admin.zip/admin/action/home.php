<?php 
    load_header();
    load_sidebar();
    load_toper('toper_dashboard');
    load_widget('content_dashboard');
    load_footer();
?>
